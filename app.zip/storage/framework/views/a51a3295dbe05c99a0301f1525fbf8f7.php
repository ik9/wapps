

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-4 mb-5">
            <div class="card shadow-sm">
                <div class="card-body">

                    <form action="<?php echo e(route("network_notes_create", $id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>


                        <div class="form-group">
                            <label for="type">نوع الملاحظة</label>
                            <select name="type" id="type" class="form-select shadow-sm">
                                <option <?php if(old('type') == ''): ?> selected <?php endif; ?> value=""></option>
                                <option <?php if(old('type') == 'عطل'): ?> selected <?php endif; ?> value="عطل">عطل</option>
                                <option <?php if(old('type') == 'تعدي'): ?> selected <?php endif; ?> value="تعدي">تعدي</option>
                                <option <?php if(old('type') == 'حالة خطرة'): ?> selected <?php endif; ?> value="حالة خطرة">حالة خطرة</option>
                            </select>
                        </div>

                        <div id="type_div1" class="form-group mb-3 mt-1">
                            <select name="type1" id="type1" class="form-select shadow-sm">
                                <option <?php if(old('type1') == 'جمبر'): ?> selected <?php endif; ?> value="جمبر">جمبر</option>
                                <option <?php if(old('type1') == 'مرابط'): ?> selected <?php endif; ?> value="مرابط">مرابط</option>
                                <option <?php if(old('type1') == 'كيبل LT'): ?> selected <?php endif; ?> value="كيبل LT">كيبل LT</option>
                                <option <?php if(old('type1') == 'كيبل HT'): ?> selected <?php endif; ?> value="كيبل HT">كيبل HT</option>
                                <option <?php if(old('type1') == 'هات كيبل LT'): ?> selected <?php endif; ?> value="هات كيبل LT">هات كيبل LT</option>
                                <option <?php if(old('type1') == 'هات كيبل HT'): ?> selected <?php endif; ?> value="هات كيبل HT">هات كيبل HT</option>
                                <option <?php if(old('type1') == 'صندوق لحام LT'): ?> selected <?php endif; ?> value="صندوق لحام LT">صندوق لحام LT</option>
                                <option <?php if(old('type1') == 'صندوق لحام HT'): ?> selected <?php endif; ?> value="صندوق لحام HT">صندوق لحام HT</option>
                                <option <?php if(old('type1') == 'عمود مائل'): ?> selected <?php endif; ?> value="عمود مائل">عمود مائل</option>
                                <option <?php if(old('type1') == 'عمود ساقط'): ?> selected <?php endif; ?> value="عمود ساقط">عمود ساقط</option>
                                <option <?php if(old('type1') == 'عمود متئاكل'): ?> selected <?php endif; ?> value="عمود متئاكل">عمود متئاكل</option>
                                <option <?php if(old('type1') == 'موصلات مرتخية'): ?> selected <?php endif; ?> value="موصلات مرتخية">موصلات مرتخية</option>
                                <option <?php if(old('type1') == 'موصلات منقطعة'): ?> selected <?php endif; ?> value="موصلات منقطعة">موصلات منقطعة</option>
                                <option <?php if(old('type1') == 'اشجار '): ?> selected <?php endif; ?> value="اشجار ">اشجار </option>
                                <option <?php if(old('type1') == 'قاطع'): ?> selected <?php endif; ?> value="قاطع">قاطع</option>
                                <option <?php if(old('type1') == 'آخرى'): ?> selected <?php endif; ?> value="آخرى">آخرى</option>
                            </select>
                        </div>
                        <div id="type_div2" class="form-group mb-3 mt-1">
                            <select name="type2" id="type2" class="form-select shadow-sm">
                                <option <?php if(old('type2') == 'عائق'): ?> selected <?php endif; ?> value="عائق">عائق</option>
                                <option <?php if(old('type2') == 'سرقة معدة'): ?> selected <?php endif; ?> value="سرقة معدة">سرقة معدة</option>
                                <option <?php if(old('type2') == 'تعدي على شبكة'): ?> selected <?php endif; ?> value="تعدي على شبكة">تعدي على شبكة</option>
                                <option <?php if(old('type2') == 'تعدي على معدة'): ?> selected <?php endif; ?> value="تعدي على معدة">تعدي على معدة</option>
                                <option <?php if(old('type2') == 'آخرى'): ?> selected <?php endif; ?> value="آخرى">آخرى</option>
                            </select>
                        </div>
                        <div id="type_div3" class="form-group mb-3 mt-1">
                            <select name="type3" id="type3" class="form-select shadow-sm">
                                <option <?php if(old('type3') == 'منخفضة'): ?> selected <?php endif; ?> value="منخفضة">منخفضة</option>
                                <option <?php if(old('type3') == 'متوسطة'): ?> selected <?php endif; ?> value="متوسطة">متوسطة</option>
                                <option <?php if(old('type3') == 'عالية'): ?> selected <?php endif; ?> value="عالية">عالية</option>
                                <option <?php if(old('type3') == 'آخرى'): ?> selected <?php endif; ?> value="آخرى">آخرى</option>
                            </select>
                        </div>

                        <script>
                            $('#type_div1').hide();
                            $('#type_div2').hide();
                            $('#type_div3').hide();
                            var mo = jQuery('#type');
                            var mov = this.value;
                            mo.change(function() {
                                $('#type_div1').hide();
                                $('#type_div2').hide();
                                $('#type_div3').hide();
                                if ($(this).val() == 'عطل') {
                                    $('#type_div1').show();
                                }
                                if ($(this).val() == 'تعدي') {
                                    $('#type_div2').show();
                                }
                                if ($(this).val() == 'حالة خطرة') {
                                    $('#type_div3').show();
                                }
                            });
                        </script>
                        <div class="form-group">
                            <label for="content">الملاحظة</label>
                            <textarea required value="<?php echo e(old('content')); ?>" name="content" id="content" class="form-control shadow-sm"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="location">إحداثيات</label>
                            <input value="<?php echo e(old('location')); ?>" name="location" id="location" class="form-control shadow-sm">
                        </div>
                        <div class="form-group">
                            <label for="photos">صور</label>
                            <input type="file" value="<?php echo e(old('photos')); ?>"  name="photos[]" id="test" class="form-control shadow-sm" multiple>
                        </div>

                        <div class="py-5 text-center">
                            <button type="submit" class="btn btn-success shadow-sm">اضافة الملاحظة</button>
                            <a href="<?php echo e(route('networks')); ?>" class="btn btn-danger">عودة</a>
                        </div>
                        
                    </form>

                </div>
            </div>
        </div>
        <br><br><br><hr><br><br><br>
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body px-5">

                    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <b><?php echo e(\App\Models\User::find($note->user_id)->name); ?></b>
                            <p><?php echo e($note->type); ?></p>
                            <p><?php echo e($note->location); ?></p>
                            <p><?php echo e($note->content); ?></p>
                            <?php $__currentLoopData = explode('*/***/*',$note->photos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($pic == ''): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                    <a target="_blank" href="<?php echo e(asset('/storage/uploads/'.$pic)); ?>"><img src="<?php echo e(asset('/storage/uploads/'.$pic)); ?>" alt="" width="100"></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($note->user_id == auth()->id() || auth()->user()->role == 'admin'): ?>
                                <a href="<?php echo e(route('network_notes_destroy', $note->id)); ?>" class="btn btn-danger">حذف</a>
                            <?php endif; ?>
                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\waed\work_out_01\resources\views/network_note.blade.php ENDPATH**/ ?>